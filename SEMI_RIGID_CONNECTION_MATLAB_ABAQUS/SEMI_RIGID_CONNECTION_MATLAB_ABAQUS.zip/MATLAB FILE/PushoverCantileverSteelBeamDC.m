%***********************************************************%
%               >> IN THE NAME OF ALLAH <<                  %
% Pushover analysis of cantilever steel Beam with           %
% semi-rigid connection                                     %
%-----------------------------------------------------------%
%     This program is written by salar delavar ghashghaei   %
%          E-mail:salar.d.ghashghaei@gmail.com              %
%-----------------------------------------------------------%
% unit: Newton-Millimeter                                   %
% Given: Stee1 Section Properties                           %
% Steel section Behavior: Elastic-Perfect Plastic           %
% Design: Moment-Rotation & Load-Displacement               %
%***********************************************************%
%        _     __                 __                        %   
%        ^    |  |               |  |                       %
%        |    |  |               |  |                       %
%             |  |               |  |                       %
%             |  |_______________|  |  +                    %
%       bf    |   _______________   |  tw                   %
%             |  |               |  |  +                    %
%        |    |  |               |  |                       %
%        v    |  |               |  |                       %
%        -     ---               ---                        %
%             |<-    2*tf+ hw     ->|                       % 
%***********************************************************%
%   Incremental Disp.  ->|                                  %
%                        |                                  %
%                        |                                  %
%                        |                                  %
%                        |                                  %
%        Reaction  <-  =====                                %
%***********************************************************%
clear all;close all;clc;
% Define Parameters in unit: mm,kN
L=3000;% [mm] length of Beam
P3=0; % [kN.mm]
P4=0; % [kN]
P5=0; % [kN] Incremental Loading [DOF (5)]
P6=0; % [kN.mm]
D5=1;% [mm] Initial Displacement  [DOF (8)] Incremental Displacement
D5max=250; % [mm] Maximum displacement [DOF (5)]
%% Section Properties
tf=9.2;% [mm] I section thickness on flange
bf=110;% [mm] I section width on flange
tw=5.9;% [mm] I section thickness of Web
hw=201.6;% [mm] Height of web
%% Steel Properties
%% Steel Properties
fy =0.3723;% [kN/mm^2] Yield strength of steel
fu =0.5114;% [kN/mm^2] Ultimate strength of steel
Es =200;% [kN/mm^2] Modulus of elasticity of steel
ey=fy/Es;% Yield strain of steel
eu=.14;% Ultimate strain of steel
d=2*tf+hw;%Section Height
Ie=((tw*hw^3)/12)+((bf*tf^3)/12)+2*((bf*tf)*(0.5*(d-tf))^2);
EI= Es*Ie; % [kN.mm^2]
EA = Es*(2*(tf*bf)+(tw*hw)); % [kN]
ty=.001;%d*ey/(.5*d); % Yield rotaion
My=2*70*7*fy*d; % [kN.mm] Yield moment
tu=.15*L*eu/(.5*d);  % Ultimate rotation
Mu=2*70*7*fu*d;  % [kN.mm] Ultimate moment
%My=(fy*Ie)/(.5*d); % Yeild Moment
%Mu=fy*(bf*tf*(d-tf)+tw*(0.5*d-tw)^2);  % Ultimate Moment
lanX=1;
lanY=0;
m = 4000; % number of calculation
itermax = 5000;% maximum number of iterations
tolerance = 1e-12; % specified tolerance for convergence
u = zeros(3,1);% initial guess value
%%% monitor cpu time
starttime = cputime;
% Element stiffness first-order coefficient
A=4*EI/L;B=6*EI/L^2;C=2*EI/L;D=12*EI/L^3;G=EA/L;
% Element stiffness second-order coefficient
AA=(4*EI/L)+(2*P4*L/15);BB=(6*EI/L^2)+(P4/10);CC=(2*EI/L)-(P4*L/30);DD=(12*EI/L^3)+(6*P4/(5*L));GG=(EA/L)+(P4/L);
% initial interal force for each element
Fele1 = zeros(6,1);
Fele2 = zeros(6,1);
%%% monitor cpu time
starttime = cputime;
%% Nonlinear Rotational Semi-Rigid Spring
nc = 2; % Moment-rotation shape parameter
Rki=My/ty;% Elastic slope of rotational spring
Rkp=(Mu-My)/(tu-ty);% Plastic slope of rotational spring
%% Force - Displacement
% Gradually increase the applied load
for i=1:m
      up=D5*i; 
        it = 0; % initialize iteration count
        residual = 100; % initialize residual
        a1=((Rki-Rkp)/((1+(abs((Rki*u(1))/My))^nc)^(1/nc)))+Rkp;
        % initial assemble global K matrix
        Kp = [A+a1 B*lanY -B*lanX C;
              B*lanY (G*lanX^2+D*lanY^2) (G-D)*lanX*lanY B*lanY;
             -B*lanX (G-D)*lanX*lanY (G*lanY^2+D*lanX^2) -B*lanX;
              C B*lanY -B*lanX A];
        Fii=Kp(:,3)*up;  
        Kinit = [A+a1 B*lanY C;
                 B*lanY (G*lanX^2+D*lanY^2) B*lanY;
                 C B*lanY A];
      Fi = [P3;P4;P5;P6];F=Fi-Fii;F=[F(1,1);F(2,1);F(4,1)];
      while (residual > tolerance)
        % assemble global K matrix
        a1=((Rki-Rkp)/((1+(abs((Rki*u(1))/My))^nc)^(1/nc)))+Rkp;
        % assemble global K matrix 
       K = [A+a1 B*lanY C;
            B*lanY (G*lanX^2+D*lanY^2) B*lanY;
            C B*lanY A];
       f=K*u-F;
        %calculate du
        du = Kinit^-1 *(-f);
        %Calculate the residual (internal-external force deviation)
        residual = max(abs(du)); % evaluate residual
        it = it+1; % increment iteration count
        if it == itermax
          fprintf('(-)For increment %1.0f trail iteration reached to Ultimate %1.0f\n',i,it)
             disp('    ## The solution for this step is not converged ##') 
            break
        end
        u = u+du; % update u
      end
              % iteration control
              if it < itermax
              fprintf('(+)Increment %1.0f : It is converged in %1.0f iteration\n',i,it)
              end

   % Rotation control     
   %if abs(u(1)) >= tu
   %  disp('      ## Spring at Support Reached to Ultimate Rotation ##')
   %  break
   %end
   % Displacement control     
   if abs(up) >= D5max
     disp('      ## Displacement reached to Ultimate Displacement ##')
     break
   end
    %% Internal force - element1          
         % Displacement Transformation Matrix
        T = [lanX lanY 0 0 0 0;
            -lanY lanX 0 0 0 0;
                   0 0 1 0 0 0;
             0 0 0 lanX lanY 0;
            0 0 0 -lanY lanX 0;
                   0 0 0 0 0 1];
        % Stiffness Matrix for each element
        Kele = [G 0 0 -G 0 0;
             0 D B 0 -D B;
             0 B A 0 -B C;
             -G 0 0 G 0 0;
           0 -D -B 0 D -B;
             0 B C 0 -B A]; 
        Fele1 = Kele*T*[0;0;u(1);u(2);up;u(3)];
        
% Force and Dispalcement for each increment
    U1(i) = u(1);
    U2(i) = u(2);
    U3(i) = up;
    U4(i) = u(3);
    INT_N_f2(i) = Fele1(2);
    INT_N_f3(i) = Fele1(3);
    INT_N_f4(i) = Fele1(4);
    INT_N_f5(i) = Fele1(5);
    INT_N_f6(i) = Fele1(6);
end
disp('====================== First-order Nonlinear =======================');
disp('rotation(D3)   X-displacement(D4)   Y-displacement(D5)   rotation(D6)');
disp('---------------------------------------------------------------------')
disp([U1' U2' U3' U4'])
disp('====================================================================');
Do1=[0;U3'];Fo1=[0;-INT_N_f2'];M1=INT_N_f3';te1=U1';
%% First-order Nonlinear bilinear fitting
SIZE=size(Do1,1);
for i=1:SIZE-1;
    h(i) = Do1(i+1)-Do1(i);
    A1(i)=(Fo1(i)+Fo1(i+1))*0.5*h(i);
end
Area=sum(A1);k0 =Fo1(2)/Do1(2);
Diy = (Fo1(i+1)*max(Do1)*0.5-Area)/(Fo1(i+1)*0.5 - k0*max(Do1)*0.5);Fy = k0*Diy;
X1 = [0;Diy;max(Do1)];Y1 = [0;Fy;Fo1(i+1)];
fprintf('=== 1st-Order Nonlinear ==+\n');
fprintf('Disp.(D4) Base Shear(D1)   \n');
fprintf('===========================\n');
fprintf('  (mm)         (kN)        \n');
fprintf('---------------------------\n');
disp([X1 Y1])
fprintf('===========================\n');
%% ABAQUS Analysis Report [mm,kN]
AbaqX=-[0
-0.0125
-0.0125
-0.0125
-0.0125
-0.0125
-0.0125
-0.0125
-0.0125
-0.0125
-0.0125
-0.0125
-0.0125
-0.0125
-0.0125
-0.0125
-0.0125
-0.0125
-0.0125
-0.0125
-0.0138521
-0.0207797
-1.86401
-4.67583
-7.0139
-10.521
-15.7817
-23.6727
-35.5092
-47.3456
-59.1821
-71.0186
-88.7734
-115.405
-142.038
-168.67
-195.302
-235.25
-250];
AbaqY=[-0
0.00284288
0.00759066
0.00770345
0.0077045
0.0077045
0.0077045
0.0077045
0.0077045
0.0077045
0.0077045
0.0077045
0.0077045
0.0077045
0.0077045
0.0077045
0.0077045
0.0077045
0.0077045
0.0077045
0.00853784
0.0128076
1.14887
2.88196
4.32307
6.48471
9.72717
14.5907
19.7999
21.2522
22.4275
23.4684
24.7836
26.225
26.9973
27.373
27.544
27.7177
27.7685];

%% Ploting
figure(1)
IMAGE=imread('PushoverCantileverSteelBeam.jpg');
image(IMAGE);axis image;axis off;
figure(2)
IMAGE=imread('PushoverCantileverSteelBeamDC.jpg');
image(IMAGE);axis image;axis off;
figure(3)
P2=plot([0;ty;tu],[0;My;Mu]);grid on;
xlabel('Rotation (rad)');
ylabel('Moment (kN.mm)');
set(P2,'LineWidth',2);grid(gca,'minor');
legend('Analysis', 'Location','NorthEastOutside');
title(['Moment-Rotation Diagram : K_\theta _e_l_a =',num2str(roundn(Rki,-4)),' (kN/rad) K_\theta _p_l_a =',num2str(roundn(Rkp,-4)),' (kN/rad)'],'FontSize',12,'color','b');
figure(4)
P3=plot(Do1,Fo1,AbaqX,AbaqY,'-.r');grid on;
xlabel('Displacement (mm)');
ylabel('Base shear (kN)');
set(P3,'LineWidth',3);grid(gca,'minor');
legend('Analysis', 'ABAQUS','Location','NorthEastOutside');
title(['Base shear-Displacement Diagram'],'FontSize',12,'color','b');
%% Display output
disp('******************* Result ********************');
disp('===========================');
disp('  Displacement   Reaction');
disp('===========================');
disp('    (m)          (kN)');
disp('---------------------------');
disp([Do1 Fo1])
disp('===========================');
fprintf(' Max Displacement (mm)= %7.4f \n',roundn(max(abs(Do1)),-3))
%%%  print time of computation
totaltime = cputime - starttime;
fprintf('\nTotal time (s)= %7.4f \n\n',totaltime)
disp('***********************************************');